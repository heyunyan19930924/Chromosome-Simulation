// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTPath3D.h"
#include "DTPlot1D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"
#include "DTSeriesPath3D.h"

#include <math.h>

DTPlot1D Computation(int region_start,int region_end,int tau_min,int tau_max,
                     double timestep,const DTSeriesPath3D &chromosome, bool doesOverlap, int omitted_steps);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);

    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    int region_start = inputFile.ReadNumber("region_start");
    int region_end = inputFile.ReadNumber("region_end");
    int tau_min = inputFile.ReadNumber("tau_min");
    int tau_max = inputFile.ReadNumber("tau_max");
    bool doesOverlap = inputFile.ReadNumber("doesOverlap");
    double timestep = inputFile.ReadNumber("timestep");
    int omitted_steps = inputFile.ReadNumber("omitted_steps");
    DTSeriesPath3D chromosome;
    Read(inputFile,"chromosome",chromosome);

    // The computation.
    DTPlot1D computed;
    clock_t t_before = clock();
    computed = Computation(region_start,region_end,tau_min,tau_max,timestep,chromosome,doesOverlap, omitted_steps);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);

    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);

    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("Plot1D","Seq_Var");

    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");

    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");

    outputFile.SaveIndex();

    return 0;
}

DTPlot1D Computation(int region_start,int region_end,int tau_min,int tau_max,
                     double timestep,const DTSeriesPath3D &chromosome, bool doesOverlap, int omitted_steps)
{
    if (tau_min <= 0) {tau_min = 1;}
    DTMutableDoubleArray toReturnData(2, tau_max - tau_min + 2);
    toReturnData(0,0) = 0;
    toReturnData(1,0) = tau_max - tau_min + 1;
    int total = chromosome.HowManySaved();
    int numberOfBeads = region_end - region_start + 1;
    DTDoubleArray currentData = chromosome(omitted_steps).Data();
    DTDoubleArray previousData;
    
    int index = 1;
    for (int i = tau_min; i <= tau_max; ++i) {
        int time_count = 1;
        int cur_step = omitted_steps + i;
        double sum = 0;
        while (cur_step < total) {
            DTDoubleArray previousData;
            if (!doesOverlap) {
                previousData = currentData;
            } else {
                previousData = chromosome(cur_step - i).Data();
            }
            currentData = chromosome(cur_step).Data();
            const double * currentDataPointer = currentData.Pointer();
            const double * previousDataPointer = previousData.Pointer();
            for (int j = region_start; j <= region_end; ++j) {
                for (int k = 0; k < 3; ++k) {
                    sum += (currentDataPointer[3*j + k] - previousDataPointer[3*j + k]) * (currentDataPointer[3*j + k] - previousDataPointer[3*j + k]);
                }
            }
            cur_step += doesOverlap?1:i;
            time_count++;
        }
        sum /= numberOfBeads;
        sum /= time_count;
        toReturnData(1,index) = sum;
        toReturnData(0,index) = i * timestep;
        index++;
    }
    
    DTPlot1D toReturn(toReturnData);

    // chromosome.Data() - DTDoubleArray - Packed representation (see header file).
    // chromosome.NumberOfLoops() - how many components there are.
    // chromosome.NumberOfPoints() - Number of xy values.
    // chromosome.ExtractLoop(int) - Get a single component.

    return toReturn;
}
