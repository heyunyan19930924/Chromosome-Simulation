// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPath3D.h"
#include "DTSeriesArray.h"
#include "DTSeriesPath3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTDoubleArray Computation(double stride,const DTSeriesPath3D &chromosome_arm,const DTSeriesArray &condensin_location);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    double stride = inputFile.ReadNumber("stride");
    DTSeriesPath3D chromosome_arm;
    Read(inputFile,"chromosome_arm",chromosome_arm);
    DTSeriesArray condensin_location;
    Read(inputFile,"condensin_location",condensin_location);
    
    // The computation.
    DTDoubleArray computed;
    clock_t t_before = clock();
    computed = Computation(stride,chromosome_arm,condensin_location);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    outputFile.Save(computed,"Var");
    outputFile.Save("NumberList","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

DTDoubleArray Computation(double stride,const DTSeriesPath3D &chromosome_arm,const DTSeriesArray &condensin_location)
{
    DTDoubleArray time_values = chromosome_arm.TimeValues();
    int number_of_beads = chromosome_arm(0).Data().n() - 1;
    DTMutableDoubleArray toReturn(number_of_beads);
    int cur_index = 0, total_index = time_values.m(), stride_int = (int) stride;
    while (cur_index < total_index) {
        double cur_time = time_values(cur_index);
        DTDoubleArray cur_condensin = condensin_location.Get(cur_time);
        const double* cur_condensin_pointer = cur_condensin.Pointer();
        int number_of_condensin = cur_condensin.n();
        for (int i = 0; i < number_of_condensin; ++i) {
            toReturn(cur_condensin_pointer[2*i+1])++;
        }
        cur_index += stride_int;
    }
    return toReturn;
}
