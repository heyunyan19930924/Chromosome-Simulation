//
//  cohesin.h
//  ChromoShake
//
//  Created by HeYunyan on 9/26/17.
//

#ifndef cohesin_h
#define cohesin_h


#endif /* cohesin_h */
