// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTPlot1D.h"
#include "DTSeriesArray.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTPlot1D Computation(const DTSeriesArray &Series_condensin_location,int Sample_size,
                     int total_beads,int start);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTSeriesArray Series_condensin_location;
    Read(inputFile,"Series condensin location",Series_condensin_location);
    int Sample_size = inputFile.ReadNumber("Sample_size");
    int total_beads = inputFile.ReadNumber("total_beads");
    int start = inputFile.ReadNumber("start");
    
    // The computation.
    DTPlot1D computed;
    clock_t t_before = clock();
    computed = Computation(Series_condensin_location,Sample_size,total_beads,start);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("Plot1D","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

DTPlot1D Computation(const DTSeriesArray &Series_condensin_location,int Sample_size,
                     int total_beads,int start)
{
    int total_instances = Series_condensin_location.HowManySaved();
    int timestep = (total_instances - start) / Sample_size;
    int cur_idx = start, loop_range = total_beads / 2;
    const DTDoubleArray time_values = Series_condensin_location.TimeValues().Copy();
    DTMutableDoubleArray loop_size_counter(loop_range);  // This stores counts for loop with size (index + 1).
    for (int i = 0; i < loop_range; ++i) {
        loop_size_counter(i) = 0;
    }
    while (cur_idx < total_instances) {
        cur_idx += timestep;
        if (cur_idx >= total_instances) {break;}
        double cur_time = time_values(cur_idx);
        DTDoubleArray cur_condensin_info = Series_condensin_location.Get(cur_time).Copy();
        int idx = 0;
        while (idx < cur_condensin_info.n()) {
            int loop_size = abs(cur_condensin_info(1,idx) - cur_condensin_info(0,idx));
            if (loop_size > total_beads / 2) {loop_size = total_beads - loop_size;}
            loop_size_counter(loop_size - 1)++;
            idx++;
        }
    }
    DTMutableDoubleArray x_values(loop_range);
    for (int i = 0; i < total_beads / 2; ++i) {
        x_values(i) = i + 1;
    }
    DTPlot1D toReturn(x_values, loop_size_counter);
    return toReturn;
}
