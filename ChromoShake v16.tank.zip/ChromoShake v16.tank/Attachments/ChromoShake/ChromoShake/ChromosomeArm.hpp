//
//  ChromosomeArm.h
//  ChromoShake
//
//  Created by HeYunyan on 8/29/17.
//
//

#ifndef ChromosomeArm_h
#define ChromosomeArm_h
#include <stdio.h>
#include "DTArguments.h"
#include "DTDataFile.h"
#include "DTDictionary.h"
#include "DTPath3D.h"
#include "DTProgress.h"
#include "DTSeriesPath3D.h"
#include "DTRandom.h"
#include "DTUtilities.h"
#include "DTPointCollection3D.h"
#include "unitConversion.h"
#include "cohesin.hpp"
#include "condensin.hpp"
#include <vector>

class ChromosomeArm {
public:
    ChromosomeArm(){};
    ChromosomeArm(double t, double timestep, int Count, const DTDictionary &coefficients, const DTDictionary &evolution, const DTDictionary &flags, const DTDictionary& differentSpringProperty, const double seed, int NumberOfBeads);
    
    // member functions
    int findClosestBead(double x,double y, double z, int excludedBead, int itself);
    void initializeForce();
    void computeDistance();
    void springForceUpdate();
    void hingeForceUpdate();
    void cylinderForceUpdate(ChromosomeArm &arm2);
    void cylinderForceUpdateSelf();
    void randomForceUpdate(DTRandom &random, double dt);
    void dragForceUpdate();
    void loopForceUpdate(const DTDoubleArray &loop_nodes);
    void excludedVolumeUpdate();
    void cohesinForceUpdate();
    void condensinForceUpdate();
    void positionUpdate(double dt);
    void positionUpdateTemp(double dt);
    double findMaxForce();
    void updateCondensinTime(const double dt, const double extrusion_power, DTRandom &random);
    void updateCondensinTimeFixedOneSite(const double dt, const double extrusionRatePower, DTRandom &random);
    void cohesinUnbindUpdate(const double unattachThreshold, DTRandom &random);
    double* CentromereSpeed(const double speed);
    void updateRandomCentromere(DTRandom &random);
    void CentromereDetach();
    void addCondensin(const int condensin_add_pos);
    void histoneTensionDetect();
    void condensinTensionDetect();
    void condensinTimeUpdate(const int condensin_index, const double ExtrusionRatePower);
    
    // Main members.
    int numberOfBeads; // Total number of beads
    int startBead; // Centromere 1
    int endBead; // Centromere 2
    bool endBeads; // 1: centromeres fixed; 0: centromeres free
    bool _centromere_detached; // 1: centromeres will detach; 0: centromeres fixed throughout the entire simulation
    DTMutableDoubleArray position; // array contains 3d positions. (3,numberOfBeads)
    DTMutableDoubleArray positionTemp; // same as position
    DTMutableDoubleArray forceArray; // array contains instant 3d force applied on each bead. (3,numberOfBeads)
    DTMutableDoubleArray distanceArray; // array cotains the pairwise 3D distance vector of beads. For speeding up. (3,numberOfBeads). [dist(bead1,bead0), dist(bead2,bead1),...,dist(bead0,beadLast)].
    DTMutableDoubleArray normArray; // Norm array of distanceArray. (1,numberOfBeads).
    Cohesin cohesinInfo; // cohesin structure contains the information of all histones in the simulation.
    Condensin condensinInfo; //condensin structure contains the information of all condensins in the simulation.
    
private:
    // These pointer arrays are for speeding up.
    double* position_pointer;
    double* distance_array_pointer;
    double* norm_array_pointer;
    double* force_array_pointer;
    const double* spring_properties_pointer;
    
    
    // Parameters
    double collisionRadius;
    double collisionScale;
    double randomScale;
    double dragCoeff;
    double cylinderCollisionScale;
    double cylinderDist;
    double massScale = 1e10;
    double centromereMean;
    double centromereStd;
    double centromereUpdateTime;
    double _centromere_dist_threshold;
    double springLength;
    double histone_spring_const;
    double condensin_spring_const;
    
    // Spring const and length table which is a 2*num_of_beads table. (0,i) stores spring const, (1,i) stores hinge const.
    DTDoubleArray _spring_properties;
};
#endif /* ChromosomeArm_h */
