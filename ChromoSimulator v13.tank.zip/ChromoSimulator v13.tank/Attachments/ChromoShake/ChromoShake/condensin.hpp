//
//  condensin.hpp
//  ChromoShake
//
//  Created by HeYunyan on 10/2/17.
//

#ifndef condensin_hpp
#define condensin_hpp
#include <stdio.h>
#include "DTArguments.h"
#include "DTDataFile.h"
#include "DTDictionary.h"
#include "DTPath3D.h"
#include "DTProgress.h"
#include "DTSeriesPath3D.h"
#include "DTRandom.h"
#include "DTUtilities.h"
#include "DTPointCollection3D.h"
#include <algorithm>
#include <random>
#include "DTRandom.h"
#include <set>
#include "unitConversion.h"

struct condensinUnit{
public:
    condensinUnit(){};
    condensinUnit(int i, int j, double t1, double t2) {strongCiteIndex = i; weakCiteIndex = j; judgeTime = t1; attachTime = t2; flag = 1; judgeTimeTracker = 0;};
    
    int strongCiteIndex;
    int weakCiteIndex;
    double judgeTime;
    double judgeTimeTracker;
    double attachTime;
    bool flag;
};

class Condensin{
public:
    Condensin(){};
    Condensin(const int NumberOfCondensin, const double JudgeTime, const double CriticalLengthNanometers,const double Increment, const int NumberOfTotalBeads, const double seed, const double unbindTime, const double rebindTime, const double unbindTimeVar, const bool unbindCondensin, const bool dynamicExtrusionRate);
    
    int numberOfCondensin, numberOfTotalBeads;
    int number_of_active_condensins;
    double judgeTime, criticalLength, initialTime;
    vector<condensinUnit> condensinConfig;
    double increment;
    double unbindTime;
    double unbindTimeVar;
    double rebindTime;
    bool unbind;
    bool dynamicExtrusion;
    DTIntArray condensin_array;
    
    void condensinArrayUpdate();
    void addCondensin(const int add_pos);
};

#endif /* condensin_hpp */
