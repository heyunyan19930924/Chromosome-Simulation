//
//  condensin.cpp
//  ChromoShake
//
//  Created by HeYunyan on 10/2/17.
//

#include "condensin.hpp"

Condensin::Condensin(const int NumberOfCondensin, const double JudgeTime, const double CriticalLengthNanometers,const double Increment, const int NumberOfTotalBeads, const double seed, const double UnbindTime, const double RebindTime, const double UnbindTimeVar, const bool unbindcondensin, const bool dynamicExtrusionRate)
{
    numberOfCondensin = NumberOfCondensin;
    numberOfTotalBeads = NumberOfTotalBeads;
    judgeTime = JudgeTime;
    criticalLength = CriticalLengthNanometers;
    criticalLength = criticalLength*criticalLength;
    increment = Increment;
    unbindTime = UnbindTime;
    unbindTimeVar = UnbindTimeVar;
    rebindTime = RebindTime;
    unbind = unbindcondensin;
    dynamicExtrusion = dynamicExtrusionRate;
    initialTime = JudgeTime;
    DTMutableIntArray tmp_condensin_array(2, numberOfCondensin);
    default_random_engine random(seed);
    DTRandom randomGenerator(seed);
    DTMutableDoubleArray randomTimeArray(numberOfCondensin);
    number_of_active_condensins  = NumberOfCondensin;
    randomGenerator.Normal(unbindTime,unbindTimeVar,randomTimeArray.Pointer(),numberOfCondensin);
    bool type;
    vector<int> tmp;
    for (int i=0;i<numberOfTotalBeads-numberOfCondensin;i++) tmp.push_back(i);
    shuffle(tmp.begin(), tmp.end(),random);
    for (int i=0;i<numberOfTotalBeads-2*numberOfCondensin;i++) tmp.pop_back();
    sort(tmp.begin(), tmp.end());
    for (int i=0;i<numberOfCondensin;i++) {
        type = rand()%2;
        if (type == 1) {
            condensinUnit tempUnit(tmp[i]+i,(tmp[i]+i+1)%numberOfTotalBeads,judgeTime,randomTimeArray(i));
            condensinConfig.push_back(tempUnit);
        } else {
            condensinUnit tempUnit((tmp[i]+i+1)%numberOfTotalBeads,tmp[i]+i,judgeTime,randomTimeArray(i));
            condensinConfig.push_back(tempUnit);
        }
    }
    condensinArrayUpdate();
}

void Condensin::condensinArrayUpdate() {
    if (number_of_active_condensins == 0) {
        DTMutableIntArray tmp;
        condensin_array = tmp.Copy();
        return;
    }
    DTMutableIntArray tmp(2, number_of_active_condensins);
    int count = 0;
    for (int i = 0; i < numberOfCondensin; ++i) {
        if (condensinConfig[i].flag) {
            tmp(0,count) = condensinConfig[i].weakCiteIndex;
            tmp(1,count) = condensinConfig[i].strongCiteIndex;
            count++;
        }
    }
    condensin_array = tmp.Copy();
}

void Condensin::addCondensin(const int add_pos)
{
    int dice = rand()%20;
    int weak_site_index = add_pos - 10 + dice;
    if (weak_site_index == add_pos) {weak_site_index++;}
    weak_site_index = (weak_site_index + numberOfTotalBeads) % numberOfTotalBeads;
    dice = rand()%2;
    int strong_site_index = ((dice == 0) ? weak_site_index + 1 : weak_site_index - 1);
    strong_site_index = (strong_site_index + numberOfTotalBeads) % numberOfTotalBeads;
    condensinUnit new_condensin(strong_site_index, weak_site_index, judgeTime, unbindTime);
    condensinConfig.push_back(new_condensin);
    numberOfCondensin++;
    number_of_active_condensins++;
    condensinArrayUpdate();
}
