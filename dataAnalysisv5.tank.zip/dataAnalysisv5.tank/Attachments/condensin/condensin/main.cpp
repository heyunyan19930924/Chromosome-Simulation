// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPointCollection3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTPointCollection3D Computation(const DTPointCollection3D &Points,const DTDoubleArray &condensin);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);

    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTPointCollection3D Points;
    Read(inputFile,"Points",Points);
    DTDoubleArray condensin = inputFile.ReadDoubleArray("condensin");

    // The computation.
    DTPointCollection3D computed;
    clock_t t_before = clock();
    computed = Computation(Points,condensin);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);

    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);

    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("PointCollection3D","Seq_Var");

    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");

    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");

    outputFile.SaveIndex();

    return 0;
}

DTPointCollection3D Computation(const DTPointCollection3D &Points,const DTDoubleArray &condensin)
{
    DTFloatArray points_data = Points.FloatData();
    const float * points_data_pointer = points_data.Pointer();
    int m = 2 * condensin.n();
    if (condensin.n() == 0) {
        DTPointCollection3D toReturn;
        return toReturn;
    }
    DTMutableFloatArray to_return_data (3,m);
    for (int i = 0; i < m; ++i) {
        int cur = 3 * condensin(i);
        for (int j = 0; j < 3; ++j) {
            to_return_data(j, i) = points_data_pointer[cur + j];
        }
    }

    // Points.Data() - DTFloatArray - a 3xN array.
    DTPointCollection3D toReturn(to_return_data);
    return toReturn;
}
