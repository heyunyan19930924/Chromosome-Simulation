// #include "DTSource.h"
#include "DTSaveError.h"

#include "DTArguments.h"
#include "DTDataFile.h"
#include "DTDictionary.h"
#include "DTPath3D.h"
#include "DTPointCollection2D.h"
#include "DTProgress.h"
#include "DTSeriesGroup.h"
#include "DTSeriesPath3D.h"
#include "DTDoubleArray.h"

//////////////////////////////////////////////////////////////////////////////
//    DT_RetGroup
//////////////////////////////////////////////////////////////////////////////

struct DT_RetGroup {
    DTPointCollection2D zAxis900;
    DTPointCollection2D zAxis600;
    DTPointCollection2D zAxis300;
    DTPointCollection2D zAxis0;
    DTPointCollection2D zAxisMinus300;
    DTPointCollection2D zAxisMinus600;
    DTPointCollection2D zAxisMinus900;
    
    void pinfo(void) const;
    void pinfoIndent(string) const;
    
    static void WriteStructure(DTDataStorage &,string);
};

void DT_RetGroup::pinfo(void) const
{
    pinfoIndent("");
}

void DT_RetGroup::pinfoIndent(string pad) const
{
    cerr << pad << "zAxis900 = "; zAxis900.pinfo();
    cerr << pad << "zAxis600 = "; zAxis600.pinfo();
    cerr << pad << "zAxis300 = "; zAxis300.pinfo();
    cerr << pad << "zAxis0 = "; zAxis0.pinfo();
    cerr << pad << "zAxisMinus300 = "; zAxisMinus300.pinfo();
    cerr << pad << "zAxisMinus600 = "; zAxisMinus600.pinfo();
    cerr << pad << "zAxisMinus900 = "; zAxisMinus900.pinfo();
}

void DT_RetGroup::WriteStructure(DTDataStorage &output,string name)
{
    output.Save("zAxis900",name+"_1N");
    output.Save("PointCollection2D",name+"_1T");
    
    output.Save("zAxis600",name+"_2N");
    output.Save("PointCollection2D",name+"_2T");
    
    output.Save("zAxis300",name+"_3N");
    output.Save("PointCollection2D",name+"_3T");
    
    output.Save("zAxis0",name+"_4N");
    output.Save("PointCollection2D",name+"_4T");
    
    output.Save("zAxisMinus300",name+"_5N");
    output.Save("PointCollection2D",name+"_5T");
    
    output.Save("zAxisMinus600",name+"_6N");
    output.Save("PointCollection2D",name+"_6T");
    
    output.Save("zAxisMinus900",name+"_7N");
    output.Save("PointCollection2D",name+"_7T");
    
    output.Save(7,name+"_N");
    output.Save("Group",name);
}

extern void Write(DTDataStorage &,string name,const DT_RetGroup &);

void Write(DTDataStorage &output,string name,const DT_RetGroup &var)
{
    // Structures for shared grids.
    DTPointCollection2D_SaveInfo Info_DTPointCollection2D;
    
    Write(output,name+"_zAxis900",var.zAxis900,Info_DTPointCollection2D);
    Write(output,name+"_zAxis600",var.zAxis600,Info_DTPointCollection2D);
    Write(output,name+"_zAxis300",var.zAxis300,Info_DTPointCollection2D);
    Write(output,name+"_zAxis0",var.zAxis0,Info_DTPointCollection2D);
    Write(output,name+"_zAxisMinus300",var.zAxisMinus300,Info_DTPointCollection2D);
    Write(output,name+"_zAxisMinus600",var.zAxisMinus600,Info_DTPointCollection2D);
    Write(output,name+"_zAxisMinus900",var.zAxisMinus900,Info_DTPointCollection2D);
    Write(output,name,DTDoubleArray()); // So that DataTank can see the variable.
}

//////////////////////////////////////////////////////////////////////////////
//    Main routine
//////////////////////////////////////////////////////////////////////////////

void Computation(int imageNumber,double timeStep,double stepSize,
                 const DTSeriesPath3D &data,double judgeDistance,
                 int fluorescentBegin,int fluorescentEnd,
                 DTSeriesGroup<DT_RetGroup> &computed);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    // Input variables.
    int imageNumber = inputFile.ReadNumber("imageNumber");
    double timeStep = inputFile.ReadNumber("timeStep");
    double stepSize = inputFile.ReadNumber("stepSize");
    DTSeriesPath3D data;
    Read(inputFile,"data",data);
    double judgeDistance = inputFile.ReadNumber("judgeDistance");
    int fluorescentBegin = inputFile.ReadNumber("fluorescentBegin");
    int fluorescentEnd = inputFile.ReadNumber("fluorescentEnd");
    
    // Output series.
    DTSeriesGroup<DT_RetGroup> computed(outputFile,"Var");
    if (DTArgumentIncludesFlag("saveInput")) { // Add -saveInput to the argument list to save the input in the output file.
        WriteOne(outputFile,"imageNumber",imageNumber);
        WriteOne(outputFile,"timeStep",timeStep);
        WriteOne(outputFile,"stepSize",stepSize);
        WriteOne(outputFile,"judgeDistance",judgeDistance);
        WriteOne(outputFile,"fluorescentBegin",fluorescentBegin);
        WriteOne(outputFile,"fluorescentEnd",fluorescentEnd);
    }
    
    
    // The computation.
    clock_t t_before = clock();
    Computation(imageNumber,timeStep,stepSize,data,judgeDistance,fluorescentBegin,fluorescentEnd,computed);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

//////////////////////////////////////////////////////////////////////////////
//    Computational routine
//////////////////////////////////////////////////////////////////////////////

void Computation(int imageNumber,double timeStep,double stepSize,
                 const DTSeriesPath3D &data,double judgeDistance,
                 int fluorescentBegin,int fluorescentEnd,
                 DTSeriesGroup<DT_RetGroup> &computed)
{

    // Insert your code here.
    double currentTime = 0;
    double totalTime = 0;
    int currentTimeIndex = 0;
    int numberOfBeads = data(0).Data()(2,0);
    DTProgress progress;
    int totalTimeIndex = data.HowManySaved();
    double simulationTimeStep = data.TimeValues()(1);
    int imageNumberEachSide = imageNumber / 2;
    double currentZAxis;
    
    while (currentTimeIndex<=totalTimeIndex) {
        if (currentTime<timeStep && currentTime != 0) {
            currentTime += simulationTimeStep;
            totalTime += simulationTimeStep;
            currentTimeIndex++;
            continue;
        }
        
        vector<DTMutableDoubleArray> imageData(imageNumber);
        int pausePos[7];
        for (int i=0;i<imageNumber;i++) {
            DTMutableDoubleArray tempArray(2,200);
            imageData[i] = tempArray.Copy();
            pausePos[i] = 0;
        }
        DT_RetGroup toReturn;
        
        //Reach image output time step.
        DTDoubleArray currentData = data(currentTimeIndex).Data().Copy();
        const double *currentDataPointer = currentData.Pointer();
        for (int i=fluorescentBegin;i<=fluorescentEnd;i++) {
            currentZAxis = currentDataPointer[3*(i+1)+2];
            for (int j=-imageNumberEachSide;j<=imageNumberEachSide;j++) {
                if (currentZAxis-j*stepSize<judgeDistance && currentZAxis-j*stepSize>-judgeDistance) {
                    imageData[j+imageNumberEachSide](0,pausePos[j+imageNumberEachSide])
                    = currentDataPointer[3*(i+1)];
                    imageData[j+imageNumberEachSide](1,pausePos[j+imageNumberEachSide])
                    = currentDataPointer[3*(i+1)+1];
                    pausePos[j+imageNumberEachSide]++;
                    break;
                }
            }
        }
        for (int i=0;i<imageNumber;i++) imageData[i] = TruncateSize(imageData[i], 2*pausePos[i]);
        //Update time series
        vector <DTPointCollection2D> tempData(imageNumber);
        for (int i=0;i<imageNumber;i++) {
            DTPointCollection2D temp(imageData[i]);
            tempData[i] = temp.Copy();
        }
        toReturn.zAxisMinus900 = tempData[0].Copy();
        toReturn.zAxisMinus600 = tempData[1].Copy();
        toReturn.zAxisMinus300 = tempData[2].Copy();
        toReturn.zAxis0 = tempData[3].Copy();
        toReturn.zAxis300 = tempData[4].Copy();
        toReturn.zAxis600 = tempData[5].Copy();
        toReturn.zAxis900 = tempData[6].Copy();
        
        
        progress.UpdatePercentage((double)currentTimeIndex/(double)totalTimeIndex);
        computed.Add(toReturn,totalTime); // Call with time>=0 and strictly increasing.
        //Update time.
        currentTime += simulationTimeStep - timeStep;
        totalTime += simulationTimeStep;
        currentTimeIndex++;
        
    }
    

    // Inside the loop, do
    //     progress.UpdatePercentage(fraction);
    //     computed.Add(returnStructure,time); // Call with time>=0 and strictly increasing.

}
