// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPath3D.h"
#include "DTSeriesPath3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

//////////////////////////////////////////////////////////////////////////////
//    DT_RetGroup
//////////////////////////////////////////////////////////////////////////////

struct DT_RetGroup {
    DTSeriesPath3D Var;
    
    void pinfo(void) const;
    void pinfoIndent(string) const;
    
    static void WriteStructure(DTDataStorage &,string);
    void SetOutputFile(DTDataStorage &output,string name);
};

void DT_RetGroup::pinfo(void) const
{
    pinfoIndent("");
}

void DT_RetGroup::pinfoIndent(string pad) const
{
    cerr << pad << "Var = "; Var.pinfo();
}

void DT_RetGroup::WriteStructure(DTDataStorage &output,string name)
{
    output.Save("Var",name+"_1N");
    output.Save("Series",name+"_1T");
    output.Save("Path3D",name+"_1T_type");
    
    output.Save(1,name+"_N");
    output.Save("Group",name);
}

void DT_RetGroup::SetOutputFile(DTDataStorage &output,string name)
{
    Var = DTSeriesPath3D(output,name+"_Var");
}

extern void WriteMissing(DTDataStorage &,string name,const DT_RetGroup &);

void WriteMissing(DTDataStorage &output,string name,const DT_RetGroup &var)
{
    Write(output,name,DTDoubleArray()); // So that DataTank can see the variable.
}

//////////////////////////////////////////////////////////////////////////////
//    End of structure definitions.
//////////////////////////////////////////////////////////////////////////////

void Computation(const DTSeriesPath3D &entire_data,int fluoBegin,int fluoEnd,DT_RetGroup &toReturn);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTSeriesPath3D entire_data;
    Read(inputFile,"entire data",entire_data);
    int fluoBegin = inputFile.ReadNumber("fluoBegin");
    int fluoEnd = inputFile.ReadNumber("fluoEnd");
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    DT_RetGroup computed;
    computed.SetOutputFile(outputFile,"Var");
    
    // The computation.
    clock_t t_before = clock();
    Computation(entire_data,fluoBegin,fluoEnd,computed);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    outputFile.Save("Group","Seq_Var");
    DT_RetGroup::WriteStructure(outputFile,"SeqInfo_Var");
    WriteMissing(outputFile,"Var",computed);
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

void Computation(const DTSeriesPath3D &entire_data,int fluoBegin,int fluoEnd,DT_RetGroup &toReturn)
{
    int totalTime = entire_data.HowManySaved();
    int numberOfNodesStored = fluoEnd-fluoBegin+1;
    for (int i=0;i<totalTime;++i) {
        const double* dataPointer = entire_data(i).Data().Pointer();
        double time = entire_data.TimeValues()(i);
        DTMutableDoubleArray data(3,numberOfNodesStored + 1);
        data(0,0) = 0;
        data(1,0) = 0;
        data(2,0) = numberOfNodesStored;
        for (int j=0;j<numberOfNodesStored;++j) {
            for (int k=0;k<3;++k) data(k,j+1) = dataPointer[3*(j+fluoBegin)+k];
        }
        DTPath3D tmpPath(data);
        toReturn.Var.Add(tmpPath, time);
    }
    // toReturn.Var - Series
}
