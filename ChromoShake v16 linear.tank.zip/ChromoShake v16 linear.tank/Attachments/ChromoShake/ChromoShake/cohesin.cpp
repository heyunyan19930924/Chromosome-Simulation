//
//  cohesin.cpp
//  ChromoShake
//
//  Created by HeYunyan on 9/26/17.
//

#include "cohesin.hpp"

Cohesin::Cohesin(int NumberOfCohesin, double halfLifeOn, double halfLifeOff, double Variance, int numberOfBeads, DTRandom &timeGenerator, default_random_engine &generator, double unattach_time, double unattach_start_time)
{
    numberOfCohesin = NumberOfCohesin;
    numberOfTotalBeads = numberOfBeads;
    variance = Variance;
    halflifeOn = halfLifeOn;
    halflifeOff = halfLifeOff;
    // Generate initial cohesin configuration.
    DTMutableDoubleArray initialLoopTime(numberOfCohesin);
    timeGenerator.Normal(halflifeOn,variance,initialLoopTime.Pointer(),numberOfCohesin);
    _unattach_time = unattach_time;
    _unattach_start_time = unattach_start_time;
 
    vector<int> overflow;
    for (int i=0;i<numberOfTotalBeads - 6*numberOfCohesin;i++) overflow.push_back(i);
    random_shuffle(overflow.begin(),overflow.end());
    for (int i=0;i<numberOfTotalBeads - 7*numberOfCohesin;i++) overflow.pop_back();
    sort(overflow.begin(),overflow.end());
    
    for (int i=0;i<numberOfTotalBeads;i++) {
        availableBeads.insert(i);
        beadsNotInLoop.insert(i);
    }
    
    for (int i = numberOfTotalBeads - 1; i > numberOfTotalBeads - 7; i--) {
        availableBeads.erase(i);
    }
    
    for (int i=0;i<NumberOfCohesin;i++) {
        int flag = rand() % 200;
        if (flag < 100) {
            double initial_portion = flag / 100.0 * halfLifeOn;
            cohesinUnit tmpUnit(overflow[i]+6*i, initial_portion);
            loopConfig.push_back(tmpUnit);
            for (int j=-6;j<7;j++) availableBeads.erase(loopConfig[i].startBeadIndex+j);
            for (int j=0;j<7;j++) beadsNotInLoop.erase(loopConfig[i].startBeadIndex+j);
        } else {
            double initial_portion = (flag - 100) / 100.0 * halfLifeOff;
            cohesinUnit tmpUnit(overflow[i]+6*i - numberOfTotalBeads, initial_portion);
            loopConfig.push_back(tmpUnit);
        }
    }
}

void Cohesin::updateTime(const double dt, DTRandom &timeGenerator) {
    // flag indicates if there are new histones attach to arm.
    bool flag = 0;
    for (int i=0;i<numberOfCohesin;i++) {
        // If unattach is turned on, histones may unattach the chromosome arm if the histone is streched long enough.
        
        loopConfig[i].remainingTime -= dt;
        loopConfig[i]._time_started += dt;
        if (loopConfig[i].remainingTime<0 && loopConfig[i].startBeadIndex<0) flag = 1;
        else if (loopConfig[i].remainingTime<0 && loopConfig[i].startBeadIndex>-1) {
            double off_time = timeGenerator.Normal(halflifeOff, variance);
            histoneDetach(i, off_time);
        }
    }
    if (!flag) return;
    for (int i=0;i<numberOfCohesin;i++) {
        if (loopConfig[i].remainingTime<0 && loopConfig[i].startBeadIndex<0){
            //New loops are forming. In loopConfig, assign a new starting bead to the first entry of the cohesin, and assign its on time on the second entry. Update availableBeads and beadsNotInLoop.
            if (availableBeads.empty()) break;
            double remainingTime = timeGenerator.Normal(halflifeOn, variance);
            histoneInsert(i, remainingTime);
        }
    }
}

void Cohesin::histoneDetach(const int index, const double detach_time)
{
    // Looped but is breaking up. In loopConfig, assign a negative value to the first entry of the cohesin, and assign its off time on the second entry. Update availableBeads and beadsNotInLoop.
    int removed_index = loopConfig[index].startBeadIndex;
    loopConfig[index].startBeadIndex -= numberOfTotalBeads;
    loopConfig[index].remainingTime = detach_time;
    // Since one histone pops off, we add beads on this histone to beadsNotInLoop, and we add beads within range of 6 from removed bead into availableBeads.
    for (int i = 0; i < 7; ++i) {
        int cur_index = removed_index + i;
        if (cur_index >= numberOfTotalBeads) {break;}
        beadsNotInLoop.insert(cur_index);
    }
    // This part we need to check both ends of each potential histone. If either end is in a loop, we should not add this to availableBeads.
    for (int i = -6; i < 7; ++i) {
        int cur_index = removed_index + i;
        if (cur_index >= numberOfTotalBeads) {continue;}
        else if (cur_index < 0) {continue;}
        int check_end_cur_index = cur_index + 6;
        if (check_end_cur_index >= numberOfTotalBeads) {
            continue;
        }
        if (beadsNotInLoop.find(check_end_cur_index) != beadsNotInLoop.end()
            && beadsNotInLoop.find(cur_index) != beadsNotInLoop.end()) {
            availableBeads.insert(cur_index);
        }
    }
}

void Cohesin::histoneInsert(const int i, const double binding_time)
{
    int tmpBead = *availableBeads.begin();
    int currentBead;
    loopConfig[i].startBeadIndex = tmpBead;
    loopConfig[i]._time_started = 0;
    loopConfig[i].remainingTime = binding_time;
    for (int j=0;j<7;j++) {
        currentBead = tmpBead+j;
        if (currentBead>numberOfTotalBeads-1) {break;}
        beadsNotInLoop.erase(currentBead);
        availableBeads.erase(currentBead);
    }
    for (int j=1;j<7;j++) {
        currentBead = tmpBead-j;
        if (currentBead<0) {continue;}
        availableBeads.erase(currentBead);
    }
}
