//
//  ChromosomeArm.cpp
//  ChromoShake
//
//  Created by HeYunyan on 8/30/17.
//
//

#include <stdio.h>
#include "ChromosomeArm.hpp"
#include "unitConversion.h"

double findMax(double *u, int start, int end);
double acos(double x);
double innerProduct(double *u, double *v);
void computeCylinderDistance(double x11,double x12, double x13, double x21, double x22, double x23, double y11, double y12, double y13, double y21, double y22, double y23,double *toReturn);
void computePointLineDistance(double x11,double x12, double x13, double y11, double y12, double y13, double y21, double y22, double y23, double *toReturn);

ChromosomeArm::ChromosomeArm(double t, double timestep, int Count, const DTDictionary &coefficients, const DTDictionary &evolution, const DTDictionary &flags, const DTDictionary& differentSpringProperty, const double seed, int NumberOfBeads)
{
    //Read in parameters
    
    double loop_radius_nanometers = coefficients("loop_radius_nanometers");
    //double cohesin_radius_microns = 0.0255;
    double node_separation_nanometers = coefficients("mass_separation_nanometers");
    double temperature_Celsius = coefficients("temperature_Celsius");
    double viscosity_centiPoise = coefficients("viscosity_centiPoise");
    double modulus_gigaPascal = coefficients("modulus_gigaPascal");
    double histone_modulus = coefficients("histone_modulus");
    double condensin_modulus = coefficients("condensin_modulus");
    double modulus_nanometers = gigaPascal_to_Pascal(modulus_gigaPascal) * 1e-9;
    double dna_radius_nanometers = coefficients("dna_radius_nanometers");
    double collision_radius_factor = coefficients("collision_radius_factor");
    double collision_force_factor = coefficients("collision_force_factor");
    double damping_radius_factor = coefficients("damping_radius_factor");
    double cylinderCollisionFactor = coefficients("cylinderCollisionFactor");
    double centromere_detach_threshold = coefficients("centromereDetachThreshold");
    bool different_spring_activate = differentSpringProperty("activate");
    int different_start_bead = differentSpringProperty("start_bead");
    int different_end_bead = differentSpringProperty("end_bead");
    double different_modulus_gigaPascal = differentSpringProperty("modulus_gigaPascal");
    double different_modulus_nanometers = gigaPascal_to_Pascal(different_modulus_gigaPascal) * 1e-9;
    
    //Unit conversion
    //double cohesin_radius_meters = microns_to_meters(cohesin_radius_microns);
    double temperature_kelvin = Celsius_to_Kelvin(temperature_Celsius);
    double viscosity_Pascal_seconds_nanometers = centiPoise_to_Pascal_seconds(viscosity_centiPoise) * 1e-9;
    double effective_damping_radius = damping_radius_factor * node_separation_nanometers;
    
    dragCoeff = mass_damping_equivalent(
                                    viscosity_Pascal_seconds_nanometers,
                                        effective_damping_radius);
    double springConst = dna_tensile_spring_constant(
                                                     node_separation_nanometers,
                                                     modulus_nanometers,
                                                     dna_radius_nanometers
                                                     );
    springConst /= dragCoeff;
    histone_spring_const = springConst * histone_modulus / modulus_gigaPascal;
    condensin_spring_const = springConst * condensin_modulus / modulus_gigaPascal;
    double different_spring_const = dna_tensile_spring_constant(
                                                    node_separation_nanometers,
                                                             different_modulus_nanometers,
                                                             dna_radius_nanometers
                                                             );
    different_spring_const /= dragCoeff;
    double HingeConst = dna_bending_spring_constant(
                                                        node_separation_nanometers,
                                                        modulus_nanometers,
                                                        dna_radius_nanometers
                                                        );
    HingeConst /= dragCoeff;
    double different_hinge_const = dna_bending_spring_constant(
                                                    node_separation_nanometers,
                                                    different_modulus_nanometers,
                                                    dna_radius_nanometers
                                                    );
    different_hinge_const /= dragCoeff;
    randomScale = 1e9 * Brownian_force_equivalent(
                                                         node_separation_nanometers,
                                                         temperature_kelvin,
                                                         viscosity_Pascal_seconds_nanometers
                                                         );
    randomScale /= dragCoeff;
    double mass_radius = collision_radius_factor * (node_separation_nanometers / 2.0);
    double collision_spring_constant = springConst * collision_force_factor;
    springLength = node_separation_nanometers;
    collisionRadius = mass_radius;
    collisionScale = collision_spring_constant;
    cylinderCollisionScale = springConst * cylinderCollisionFactor;
    cylinderDist = coefficients("cylinderDistNanometers");
    startBead = evolution("startBead");
    endBead = evolution("endBead");
    endBeads = flags("endBeads");
    centromereMean = coefficients("centromereMean");
    centromereStd = coefficients("centromereStd");
    centromereUpdateTime = coefficients("centromereUpdateTime");
    
    //Initialize geometry and assign mass
    numberOfBeads = NumberOfBeads;
    DTMutableDoubleArray iniGeo(3,numberOfBeads),iniForceArray(3,numberOfBeads),iniDistArray(3,numberOfBeads), iniNormArray(numberOfBeads);
    
    // Initialize geometry and bead mass. Initial configuration is a circle.
    //bool endBeads = flags("endBeads");
    double total_length = coefficients("centromereMean");
    double length_per_segment = total_length / (NumberOfBeads - 1);
    for (int i=0;i<numberOfBeads;i++) {
        iniGeo(0,i) = i * length_per_segment;// x-coordinate
        iniGeo(1,i) = 0;// y-coordinate
        iniGeo(2,i) = 0; // z-coordinate
        for (int j=0;j<3;j++) {
            iniForceArray(j,i) = 0;
            iniDistArray(j,i) = 0;
        }
        iniNormArray(i) = 0;
    }
    position = iniGeo.Copy();
    positionTemp = iniGeo.Copy();
    forceArray = iniForceArray.Copy();
    distanceArray = iniDistArray.Copy();
    normArray = iniNormArray.Copy();
    _centromere_detached = false;
    _centromere_dist_threshold = centromere_detach_threshold * centromere_detach_threshold;
    
    DTMutableDoubleArray tmp_spring_table(2, numberOfBeads);
    for (int i = 0; i < numberOfBeads; ++i) {
        tmp_spring_table(0,i) = springConst;
        tmp_spring_table(1,i) = HingeConst;
    }
    if (different_spring_activate) {
        for (int i = different_start_bead; i < different_end_bead; ++i) {
            tmp_spring_table(0,i) = different_spring_const;
            tmp_spring_table(1,i) = different_hinge_const;
        }
    }
    _spring_properties = tmp_spring_table.Copy();
}

//Compute distance vector and its norm between two adjacent beads. Prepare to use in other functions.
void ChromosomeArm::computeDistance(){
    //temporarily stores distance vector and its norm between adjacent beads.
    const double *positionD = position.Pointer();
    double scale;
    for (int i=0;i<numberOfBeads-1;i++) {
        normArray(i) = 0;
        for (int j=0;j<3;j++) {
            scale = positionD[i*3+j+3] - positionD[i*3+j];
            distanceArray(j,i) = scale;
            normArray(i) += scale*scale;
        }
        normArray(i) = sqrt(normArray(i));
    }
    int last_bead = numberOfBeads - 1;
    normArray(last_bead) = 0;
    for (int j=0;j<3;j++) {
        scale = positionD[j] - positionD[last_bead*3+j];
        distanceArray(j,last_bead) = scale;
        normArray(last_bead) += scale*scale;
    }
    normArray(last_bead) = sqrt(normArray(last_bead));
}

void ChromosomeArm::springForceUpdate()
{
    const double* spring_property_P = _spring_properties.Pointer();
    const double *distanceArrayD = distanceArray.Pointer();
    const double *normArrayD = normArray.Pointer();
    double scale;
    for (int i=0;i<numberOfBeads - 1;i++){
        for (int j=0;j<3;j++){
            scale = spring_property_P[2*i]*distanceArrayD[i*3+j]*(1 - springLength/normArrayD[i]);
            forceArray(j,i) += scale;
            forceArray(j,i+1) -= scale;
        }
    }
}

void ChromosomeArm::hingeForceUpdate() {
    //cross distance, forward distance, backward distance
    double dxyz1[3],dxyz2[3];
    double norm1,norm2,scale,phi;
    const double *distArrayD = distanceArray.Pointer();
    const double *normArrayD = normArray.Pointer();
    const double* spring_property_P = _spring_properties.Pointer();
    
    int last_bead = numberOfBeads - 1;
    //now repeat for other beads. Notice that we can save some calculations by copying previous -dxyz2, -norm2 to dxyz3, norm3.
    for (int i=1;i<numberOfBeads - 1;i++){
        for (int j=0;j<3;j++) {
            if (i == 0) {
                dxyz1[j] = distArrayD[3 * last_bead + j];
            }
            else {dxyz1[j] = distArrayD[3 * (i - 1) + j];}
            dxyz2[j] = distArrayD[3 * i + j];
        }
        if (i == 0) {norm1 = normArrayD[last_bead];}
        else {norm1 = normArrayD[i - 1];}
        norm2 = normArrayD[i];
        scale = (dxyz1[0] * dxyz2[0] + dxyz1[1] * dxyz2[1] + dxyz1[2] * dxyz2[2]) / (norm1 * norm2); // cos(phi)
        phi = acos(scale); // approximation of arccos
        
        // now compute direction of hinge force
        for (int j=0;j<3;j++) dxyz1[j] = -dxyz1[j]/norm1 + dxyz2[j]/norm2;
        norm1  = sqrt(dxyz1[0]*dxyz1[0] + dxyz1[1]*dxyz1[1] + dxyz1[2]*dxyz1[2]);
        
        //
        if (norm1 > 1e-10) {
            for (int j=0;j<3;j++) {
                scale = spring_property_P[2*i+1]*phi*dxyz1[j]/norm1;
                forceArray(j,i) += scale;
                if (i == 0) {forceArray(j,last_bead) -= scale/2;}
                else {forceArray(j,i-1) -= scale/2;}
                if (i == (last_bead)) {forceArray(j,0) -= scale/2;}
                else {forceArray(j,i+1) -= scale/2;}
            }
        }
    }
}

void ChromosomeArm::cylinderForceUpdate( ChromosomeArm &arm2) {
    double *positionD = position.Pointer();
    double *positionY = arm2.position.Pointer();
    // vector<double> distanceInfo(3);
    double distanceInfo[3];
    double scale,tmpForce;
    double x1S1,x2S1,x1S2,x2S2;
    double y1S1,y2S1,y1S2,y2S2;
    double z1S1,z2S1,z1S2,z2S2;
    double minX,maxX,minY,maxY,minZ,maxZ;
    int i3,j3;
    for (int i=0;i<numberOfBeads-1;i++) {
        i3 = 3*i;
        x1S1 = positionD[i3];
        y1S1 = positionD[i3+1];
        z1S1 = positionD[i3+2];
        x2S1 = positionD[i3+3];
        y2S1 = positionD[i3+4];
        z2S1 = positionD[i3+5];
        minX = std::min(x1S1,x2S1)-cylinderDist;
        maxX = std::max(x1S1,x2S1)+cylinderDist;
        minY = std::min(y1S1,y2S1)-cylinderDist;
        maxY = std::max(y1S1,y2S1)+cylinderDist;
        minZ = std::min(z1S1,z2S1)-cylinderDist;
        maxZ = std::max(z1S1,z2S1)+cylinderDist;
        for (int j=0;j<arm2.numberOfBeads-1;j++){
            j3 = j*3;
            x1S2 = positionY[j3];
            y1S2 = positionY[j3+1];
            z1S2 = positionY[j3+2];
            x2S2 = positionY[j3+3];
            y2S2 = positionY[j3+4];
            z2S2 = positionY[j3+5];
            if (x1S2<minX && x2S2<minX) continue;
            if (x1S2>maxX && x2S2>maxX) continue;
            if (y1S2<minY && y2S2<minY) continue;
            if (y1S2>maxY && y2S2>maxY) continue;
            if (z1S2<minZ && z2S2<minZ) continue;
            if (z1S2>maxZ && z2S2>maxZ) continue;
            computeCylinderDistance(x1S1, y1S1,z1S1, x2S1, y2S1,z2S1,
                                    x1S2, y1S2,z1S2, x2S2, y2S2,z2S2,
                                    distanceInfo);
            if (distanceInfo[0]>cylinderDist) continue;
            scale = cylinderDist/distanceInfo[0]-1;
            scale *= collisionScale;
            for (int k=0;k<3;k++) {
                tmpForce = scale*((1-distanceInfo[1])*positionD[3*i+k]+distanceInfo[1]*positionD[3*i+3+k]-(1-distanceInfo[2])*positionY[3*j+k]-distanceInfo[2]*positionY[3*j+3+k]);
                forceArray(k,i) += (1-distanceInfo[1])*tmpForce;
                forceArray(k,i+1) += distanceInfo[1]*tmpForce;
                arm2.forceArray(k,j) -= (1-distanceInfo[2])*tmpForce;
                arm2.forceArray(k,j+1) -= distanceInfo[2]*tmpForce;
            }
        }
    }
}

void ChromosomeArm::cylinderForceUpdateSelf(){
    double *positionD = position.Pointer();
    //distanceInfo(0) stores distance between cylinders. distanceInfo(1) stores s. distanceInfo(2) stores t.
    double distanceInfo[3];
    double scale,tmpForce;
    double x1S1,x2S1,x1S2,x2S2;
    double y1S1,y2S1,y1S2,y2S2;
    double z1S1,z2S1,z1S2,z2S2;
    double minX,maxX,minY,maxY,minZ,maxZ;
    int i3,j3;
    if (numberOfBeads<4) return;
    //int howManyComputed = 0;
    //int howManyWasted = 0;
    for (int i=0;i<numberOfBeads-3;i++) {
        i3 = i*3;
        x1S1 = positionD[i3];
        y1S1 = positionD[i3+1];
        z1S1 = positionD[i3+2];
        x2S1 = positionD[i3+3];
        y2S1 = positionD[i3+4];
        z2S1 = positionD[i3+5];
        minX = std::min(x1S1,x2S1)-cylinderDist;
        maxX = std::max(x1S1,x2S1)+cylinderDist;
        minY = std::min(y1S1,y2S1)-cylinderDist;
        maxY = std::max(y1S1,y2S1)+cylinderDist;
        minZ = std::min(z1S1,z2S1)-cylinderDist;
        maxZ = std::max(z1S1,z2S1)+cylinderDist;
        for (int j=i+2;j<numberOfBeads-1;j++) {
            j3 = j*3;
            x1S2 = positionD[j3];
            y1S2 = positionD[j3+1];
            z1S2 = positionD[j3+2];
            x2S2 = positionD[j3+3];
            y2S2 = positionD[j3+4];
            z2S2 = positionD[j3+5];
            if (x1S2<minX && x2S2<minX) continue;
            if (x1S2>maxX && x2S2>maxX) continue;
            if (y1S2<minY && y2S2<minY) continue;
            if (y1S2>maxY && y2S2>maxY) continue;
            if (z1S2<minZ && z2S2<minZ) continue;
            if (z1S2>maxZ && z2S2>maxZ) continue;
            computeCylinderDistance(x1S1, y1S1,z1S1, x2S1, y2S1,z2S1,
                                    x1S2, y1S2,z1S2, x2S2, y2S2,z2S2,
                                    distanceInfo);
            //howManyComputed++;
            if (distanceInfo[0]>cylinderDist) {
                //howManyWasted++;
                continue;
            }
            scale = cylinderDist/distanceInfo[0]-1;
            scale *= cylinderCollisionScale;
            for (int k=0;k<3;k++) {
                tmpForce = scale*(positionD[3*i+k]+distanceInfo[1]*positionD[3*i+3+k]-positionD[3*j+k]-distanceInfo[2]*positionD[3*j+3+k]);
                forceArray(k,i) += (1-distanceInfo[1])*tmpForce;
                forceArray(k,i+1) += distanceInfo[1]*tmpForce;
                forceArray(k,j) -= (1-distanceInfo[2])*tmpForce;
                forceArray(k,j+1) -= distanceInfo[2]*tmpForce;
            }
        }
    }
    
    // cerr << "comp = " << howManyComputed << ", wast = " << howManyWasted << endl;
}

void ChromosomeArm:: randomForceUpdate(DTRandom &random, double dt)
{
    DTMutableDoubleArray randomNoiseWorkArray(3,numberOfBeads);
    double scale = randomScale/sqrt(dt);
    random.Normal(randomNoiseWorkArray.Pointer(),3*numberOfBeads);
    randomNoiseWorkArray *= scale;
    forceArray += randomNoiseWorkArray;
}

void ChromosomeArm::loopForceUpdate(const DTDoubleArray &loop_nodes) {
    int loopNumber = loop_nodes.Length()/2;
    double scale, norm;
    DTMutableDoubleArray distVector(3);
    const double *positionD = position.Pointer();
    for (int i=0;i<loopNumber;i++) {
        norm = 0;
        for (int j=0;j<3;j++) {
            distVector(j) = positionD[3*(int)loop_nodes(2*i+1)+j] - positionD[3*(int)loop_nodes(2*i)+j];
            norm += distVector(j)*distVector(j);
        }
        norm = sqrt(norm);
        for (int j=0;j<3;j++) {
            scale = histone_spring_const*distVector(j)*(1 - springLength/norm);
            forceArray(j,loop_nodes(2*i)) += scale;
            forceArray(j,loop_nodes(2*i+1)) -= scale;
        }
    }
}

void ChromosomeArm::excludedVolumeUpdate()
{
    double norm, scale;
    const double *positionD = position.Pointer();
    double dx,dy,dz;
    int i3 = 0;
    int j3;
    double commpareDistSquare = collisionRadius*collisionRadius*4;
    double compareDist = 2 * collisionRadius;
    for (int i=0;i<numberOfBeads - 1;i++) {
        i3 = 3*i;
        for (int j=i+1;j<numberOfBeads;j++) {
            j3 = j*3;
            dx = positionD[i3] - positionD[j3];
            if (dx > compareDist || dx < -compareDist) {continue;}
            dy = positionD[i3+1] - positionD[j3+1];
            if (dy > compareDist || dy < -compareDist) {continue;}
            dz = positionD[i3+2] - positionD[j3+2];
            if (dz > compareDist || dz < -compareDist) {continue;}
            norm = dx*dx + dy*dy + dz*dz;
            if (norm<commpareDistSquare) {
                norm = sqrt(norm);
                scale = collisionScale*(2*collisionRadius-norm)/norm;
                forceArray(0,i) += scale*dx;
                forceArray(0,j) -= scale*dx;
                forceArray(1,i) += scale*dy;
                forceArray(1,j) -= scale*dy;
                forceArray(2,i) += scale*dz;
                forceArray(2,j) -= scale*dz;
            }
        }
    }
}

void ChromosomeArm::positionUpdate(double dt) {
    const double *forceArrayD = forceArray.Pointer();
    for (int i=0;i<numberOfBeads;i++) {
        if (endBeads) {
            if (i==startBead || i==endBead) {
                for (int j=0;j<3;j++) positionTemp(j,i) +=  dt*forceArrayD[3*i+j]/massScale;
            } else {
                for (int j=0;j<3;j++) positionTemp(j,i) +=  dt*forceArrayD[3*i+j];
            }
        } else {
            for (int j=0;j<3;j++) positionTemp(j,i) +=  dt*forceArrayD[3*i+j];
        }
    }
    position = positionTemp.Copy();
}

void ChromosomeArm::positionUpdateTemp(double dt) {
    const double *forceArrayD = forceArray.Pointer();
    for (int i=0;i<numberOfBeads;i++) {
        if (endBeads) {
            if (i!=startBead && i!=endBead) {
                for (int j=0;j<3;j++) position(j,i) +=  dt*forceArrayD[3*i+j];
            }
        } else {
            for (int j=0;j<3;j++) position(j,i) += dt*forceArrayD[3*i+j];
        }
    }
}

double ChromosomeArm::findMaxForce(){
    double *forceTempD = forceArray.Pointer();
    return *max_element(forceTempD, forceTempD+3*numberOfBeads);
}

void ChromosomeArm::updateCondensinTime(const double dt, DTRandom &random)
{
    const double *pointerD = position.Pointer();
    double dx,dy,dz,dist,newX,newY,newZ;
    double increment = condensinInfo.increment;
    int strongBead, weakBead;
    for (int i=0;i<condensinInfo.numberOfCondensin;i++) {
        condensinInfo.condensinConfig[i].attachTime -= dt;
        condensinInfo.condensinConfig[i].judgeTime -= dt;
        if (condensinInfo.unbind && condensinInfo.condensinConfig[i].attachTime < 0 && condensinInfo.condensinConfig[i].flag == 1) {
            condensinInfo.condensinConfig[i].flag = 0;
            condensinInfo.condensinConfig[i].attachTime = condensinInfo.rebindTime;
            continue;
        } else if (condensinInfo.unbind && condensinInfo.condensinConfig[i].attachTime < 0 && condensinInfo.condensinConfig[i].flag == 0) {
            //disattached condensin rebinds to chromosome arm.
            condensinInfo.condensinConfig[i].flag = 1;
            condensinInfo.condensinConfig[i].strongCiteIndex = rand()%numberOfBeads;
            condensinInfo.condensinConfig[i].weakCiteIndex = condensinInfo.condensinConfig[i].strongCiteIndex + pow(-1,rand());
            condensinInfo.condensinConfig[i].weakCiteIndex = condensinInfo.condensinConfig[i].weakCiteIndex % numberOfBeads;
            condensinInfo.condensinConfig[i].attachTime = random.Normal(condensinInfo.unbindTime, condensinInfo.unbindTimeVar);
            condensinInfo.condensinConfig[i].judgeTime = condensinInfo.judgeTime;
            continue;
        }
        if (condensinInfo.condensinConfig[i].judgeTime<0 && condensinInfo.condensinConfig[i].flag == 1) {
            condensinInfo.condensinConfig[i].judgeTime = condensinInfo.judgeTime;
            strongBead = condensinInfo.condensinConfig[i].strongCiteIndex;
            weakBead = condensinInfo.condensinConfig[i].weakCiteIndex;
            dx = -pointerD[3*weakBead]+pointerD[3*strongBead];
            dy = -pointerD[3*weakBead+1]+pointerD[3*strongBead+1];
            dz = -pointerD[3*weakBead+2]+pointerD[3*strongBead+2];
            dist = dx*dx+dy*dy+dz*dz;
            if (dist>condensinInfo.criticalLength) {
                condensinInfo.condensinConfig[i].weakCiteIndex = findClosestBead(pointerD[3*strongBead],pointerD[3*strongBead+1],pointerD[3*strongBead+2],weakBead,strongBead);
            } else{
                dist = sqrt(dist);
                newX = pointerD[3*strongBead]+increment*dx/dist;
                newY = pointerD[3*strongBead+1]+increment*dy/dist;
                newZ = pointerD[3*strongBead+2]+increment*dz/dist;
                condensinInfo.condensinConfig[i].strongCiteIndex = findClosestBead(newX,newY,newZ,strongBead,weakBead);
            }
        }
    }
}

void ChromosomeArm::updateCondensinTimeFixedOneSite(const double dt, const double extrusionRatePower, DTRandom &random)
{
    const double *pointerD = position.Pointer();
    double dx,dy,dz,dist,newX,newY,newZ;
    double increment = condensinInfo.increment;
    int strongBead, weakBead;
    bool condensin_changed = false;
    for (int i=0;i<condensinInfo.numberOfCondensin;i++) {
        condensinInfo.condensinConfig[i].attachTime -= dt;
        if (condensinInfo.condensinConfig[i].weakCiteIndex == startBead || condensinInfo.condensinConfig[i].weakCiteIndex == endBead) {
            swap(condensinInfo.condensinConfig[i].weakCiteIndex, condensinInfo.condensinConfig[i].strongCiteIndex);
        }
        if (condensinInfo.unbind && condensinInfo.condensinConfig[i].attachTime < 0 && condensinInfo.condensinConfig[i].flag == 1) {
            //condensin unbinds.
            condensinInfo.condensinConfig[i].flag = 0;
            condensinInfo.condensinConfig[i].attachTime = condensinInfo.rebindTime;
            condensin_changed  = true;
            condensinInfo.number_of_active_condensins--;
            continue;
        }
        if (condensinInfo.unbind && condensinInfo.condensinConfig[i].attachTime <= 0 && condensinInfo.condensinConfig[i].flag == 0) {
            //disattached condensin rebinds to chromosome arm.
            condensinInfo.condensinConfig[i].flag = 1;
            int tmp = rand()%numberOfBeads;
            if (endBeads && (tmp == startBead || tmp == endBead)) {
                tmp++;
            }
            condensinInfo.condensinConfig[i].weakCiteIndex = tmp;
            tmp += pow(-1,rand()%2);
            if (tmp < 0) {tmp += numberOfBeads;}
            if (tmp >= numberOfBeads) {tmp -= numberOfBeads;}
            condensinInfo.condensinConfig[i].strongCiteIndex = tmp;
            condensinInfo.condensinConfig[i].attachTime = random.Normal(condensinInfo.unbindTime, condensinInfo.unbindTimeVar);
            condensinInfo.condensinConfig[i].judgeTimeTracker = 0;
            condensinInfo.condensinConfig[i].judgeTime = condensinInfo.initialTime;
            condensin_changed = true;
            condensinInfo.number_of_active_condensins++;
            continue;
        }
        if (condensinInfo.unbind && condensinInfo.condensinConfig[i].flag == 0) {
            continue;
        }
        condensinInfo.condensinConfig[i].judgeTimeTracker += dt;
        condensinTimeUpdate(i, extrusionRatePower);
        if (condensinInfo.condensinConfig[i].judgeTimeTracker > condensinInfo.condensinConfig[i].judgeTime) {
            // condensinConfig[i] take one step
            condensinInfo.condensinConfig[i].judgeTimeTracker = 0;
            weakBead = condensinInfo.condensinConfig[i].weakCiteIndex;
            strongBead = condensinInfo.condensinConfig[i].strongCiteIndex;
            dx = - pointerD[3*weakBead] + pointerD[3*strongBead];
            dy = - pointerD[3*weakBead+1] + pointerD[3*strongBead+1];
            dz = - pointerD[3*weakBead+2] + pointerD[3*strongBead+2];
            dist = sqrt(dx * dx + dy * dy + dz * dz);
            newX = pointerD[3*strongBead] + increment * dx / dist;
            newY = pointerD[3*strongBead+1] + increment * dy / dist;
            newZ = pointerD[3*strongBead+2] + increment * dz / dist;
            condensinInfo.condensinConfig[i].strongCiteIndex = findClosestBead(newX,newY,newZ,strongBead,weakBead);
            condensin_changed  = true;
        }
    }
    if (condensin_changed) {condensinInfo.condensinArrayUpdate();}
}

void ChromosomeArm::condensinTimeUpdate(const int condensin_index, const double ExtrusionRatePower) {
    const double* norm_array_pointer = normArray.Pointer();
    // Detect greatest tension among all 4 springs 2 sites attach to. Unbind time scales with it.
    if (condensinInfo.dynamicExtrusion) {
        double max1 = 0;
        int strongBead = condensinInfo.condensinConfig[condensin_index].strongCiteIndex;
        int weakBead = condensinInfo.condensinConfig[condensin_index].weakCiteIndex;
        if (strongBead != numberOfBeads - 1 && weakBead != numberOfBeads - 1) {
            max1 = max(norm_array_pointer[strongBead], norm_array_pointer[weakBead]);
        } else if (strongBead != numberOfBeads - 1) {
            max1 = norm_array_pointer[strongBead];
        } else {
            max1 = norm_array_pointer[weakBead];
        }
        if (strongBead > 0) {strongBead--;}
        if (weakBead > 0) {weakBead--;}
        double max2 = max(norm_array_pointer[strongBead], norm_array_pointer[weakBead]);
        max1 = max(max1, max2);
        if (max1 < springLength) {
            condensinInfo.condensinConfig[condensin_index].judgeTime = condensinInfo.initialTime;
            
        }
        else {
            condensinInfo.condensinConfig[condensin_index].judgeTime = condensinInfo.initialTime * pow((max1 / springLength), ExtrusionRatePower);
        }
    } else {condensinInfo.condensinConfig[condensin_index].judgeTime = condensinInfo.initialTime;}
}

void::ChromosomeArm::cohesinForceUpdate(){
    double *positionD = position.Pointer();
    double dx,dy,dz,norm,scale;
    for (int i=0;i<cohesinInfo.numberOfCohesin;i++){
        int nodeIndex = cohesinInfo.loopConfig[i].startBeadIndex;
        if (nodeIndex<0) continue;
        int anotherNodeIndex = nodeIndex+6;
        if (anotherNodeIndex>numberOfBeads-1) {anotherNodeIndex = anotherNodeIndex-numberOfBeads;}
        dx = positionD[3*anotherNodeIndex] - positionD[3*nodeIndex];
        dy = positionD[3*anotherNodeIndex+1] - positionD[3*nodeIndex+1];
        dz = positionD[3*anotherNodeIndex+2] - positionD[3*nodeIndex+2];
        norm = sqrt(dx*dx+dy*dy+dz*dz);
        scale = histone_spring_const*dx*(1-springLength/norm);
        forceArray(0,nodeIndex) += scale;
        forceArray(0,anotherNodeIndex) -= scale;
        scale = histone_spring_const*dy*(1-springLength/norm);
        forceArray(1,nodeIndex) += scale;
        forceArray(1,anotherNodeIndex) -= scale;
        scale = histone_spring_const*dz*(1-springLength/norm);
        forceArray(2,nodeIndex) += scale;
        forceArray(2,anotherNodeIndex) -= scale;
    }
}

void::ChromosomeArm::condensinForceUpdate(){
    double *positionD = position.Pointer();
    double dx,dy,dz,norm,scale;
    for (int i=0;i<condensinInfo.numberOfCondensin;i++){
        if (!condensinInfo.condensinConfig[i].flag) continue;
        int nodeIndex = condensinInfo.condensinConfig[i].strongCiteIndex;
        int anotherNodeIndex = condensinInfo.condensinConfig[i].weakCiteIndex;
        dx = positionD[3*anotherNodeIndex] - positionD[3*nodeIndex];
        dy = positionD[3*anotherNodeIndex+1] - positionD[3*nodeIndex+1];
        dz = positionD[3*anotherNodeIndex+2] - positionD[3*nodeIndex+2];
        norm = sqrt(dx*dx+dy*dy+dz*dz);
        scale = condensin_spring_const*dx*(1-springLength/norm);
        forceArray(0,nodeIndex) += scale;
        forceArray(0,anotherNodeIndex) -= scale;
        scale = condensin_spring_const*dy*(1-springLength/norm);
        forceArray(1,nodeIndex) += scale;
        forceArray(1,anotherNodeIndex) -= scale;
        scale = condensin_spring_const*dz*(1-springLength/norm);
        forceArray(2,nodeIndex) += scale;
        forceArray(2,anotherNodeIndex) -= scale;
    }
}

void::ChromosomeArm::initializeForce(){
    for (int i=0;i<numberOfBeads;i++) {
        for (int j=0;j<3;j++) {
            forceArray(j,i) = 0;
            distanceArray(j,i) = 0;
        }
        normArray(i) = 0;
    }
}

void computeCylinderDistance(double x11,double x12, double x13, double x21, double x22, double x23, double y11, double y12, double y13, double y21, double y22, double y23,double *toReturn)
{
    // vector<double> toReturn(3);
    double u[3] = {x21-x11,x22-x12,x23-x13};
    double v[3] = {y21-y11,y22-y12,y23-y13};
    double w[3] = {x11-y11,x12-y12,x13-y13};
    double uNormS = innerProduct(u, u);
    double vNormS = innerProduct(v, v);
    double crossProduct = innerProduct(u, v);
    double a = innerProduct(u, w);
    double b = innerProduct(v, w);
    double  scale = uNormS*vNormS - crossProduct*crossProduct;
    double tmpDist[2];
    
    // special condition occurs when scale = 0, which corresponds to the condition that two line segments are parallel.
    if (fabs(scale)<1e-40) {
        double s = -b/crossProduct;
        if (s<=1 && s>=0) {
            double distanceVec[3] = {w[0]+s*u[0],w[1]+s*u[1],w[2]+s*u[2]};
            toReturn[0] = sqrt(innerProduct(distanceVec, distanceVec));
            toReturn[1] = s;
            toReturn[2] = 0;
        } else if (s>1){
            computePointLineDistance(x21, x22, x23, y11, y12, y13, y21, y22, y23,tmpDist);
            toReturn[0] = tmpDist[0];
            toReturn[1] = 1;
            toReturn[2] = tmpDist[1];
        } else {
            computePointLineDistance(x11, x12, x13, y11, y12, y13, y21, y22, y23,tmpDist);
            toReturn[0] = tmpDist[0];
            toReturn[1] = 0;
            toReturn[2] = tmpDist[1];
        }
        return;
    }
    
    //s and t are the parameters such that X1+sX2 and Y1+tY2 are the closest point to each other.
    double s = (crossProduct*b-vNormS*a)/scale;
    double t = (uNormS*b-crossProduct*a)/scale;
    
    if (t>1) {
        toReturn[2] = 1;
        if (s >=0 && s<=1) {
            computePointLineDistance(y21, y22, y23, x11, x12, x13, x21, x22, x23,tmpDist);
            toReturn[0] = tmpDist[0];
            toReturn[1] = tmpDist[1];
        } else {
            double d[3] = {y21-x11,y22-x12,y23-x13};
            double norm1 = innerProduct(d, d);
            toReturn[1] = 0;
            d[0] = y21-x21;d[1] = y22-x22; d[2] = y23-x23;
            if (innerProduct(d, d)<norm1) {
                toReturn[0] = sqrt(innerProduct(d, d));
                toReturn[1] = 1;
            } else toReturn[0] = sqrt(norm1);
        }
        return;
    } else if (t<0) {
        toReturn[2] = 0;
        if (s >=0 && s<=1) {
            computePointLineDistance(y11, y12, y13, x11, x12, x13, x21, x22, x23,tmpDist);
            toReturn[0] = tmpDist[0];
            toReturn[1] = tmpDist[1];
        } else {
            double norm1 = innerProduct(w, w);
            toReturn[1] = 0;
            double d[3] = {y11-x21,y12-x22,y13-x23};
            if (innerProduct(d, d)<norm1) {
                toReturn[0] = sqrt(innerProduct(d, d));
                toReturn[1] = 1;
            } else toReturn[0] = sqrt(norm1);
        }
        return;
    }
    
    if (s>1) {
        toReturn[1] = 1;
        computePointLineDistance(x21, x22, x23, y11, y12, y13, y21, y22, y23,tmpDist);
        toReturn[0] = tmpDist[0];
        toReturn[2] = tmpDist[1];
        return;
        //return toReturn;
    } else if (s<0) {
        toReturn[1] = 0;
        computePointLineDistance(x11, x12, x13, y11, y12, y13, y21, y22, y23,tmpDist);
        toReturn[0] = tmpDist[0];
        toReturn[2] = tmpDist[1];
        return;
        //return toReturn;
    }
    //last situation: 0<=s,t<=1.
    double distanceVec[3] = {w[0]+s*u[0]-t*v[0],w[1]+s*u[1]-t*v[1],w[2]+s*u[2]-t*v[2]};
    toReturn[0] = sqrt(innerProduct(distanceVec, distanceVec));
    toReturn[1] = s;
    toReturn[2] = t;
    return;
    // return toReturn;
}

double innerProduct(double *u, double *v){
    return u[0]*v[0]+u[1]*v[1]+u[2]*v[2];
};

void computePointLineDistance(double x11,double x12, double x13, double y11, double y12, double y13, double y21, double y22, double y23, double *toReturn)
{
    //toReturn(0) returns the distance, toReturn(1) returns the coefficient s.
    double X[3] = {x11,x12,x13},Y1[3] = {y11,y12,y13},Y2[3] = {y21,y22,y23};
    double scale = innerProduct(Y1, Y1)-2*innerProduct(Y1, Y2)+innerProduct(Y2, Y2);
    double u[3] = {x11-y11,x12-y12,x13-y13},v[3] = {y21-y11,y22-y12,y23-y13},w[3] = {x11-y21,x12-y22,x13-y23};
    
    //Special case occurs when X is on the line.
    if (scale <1e-25) {
        double ratio = innerProduct(u,v)/innerProduct(v,v);
        if (ratio>1) {
            toReturn[0] = sqrt(innerProduct(w, w));
            toReturn[1] = 1;
        } else if (ratio<0) {
            toReturn[0] = sqrt(innerProduct(u, u));
            toReturn[1] = 0;
        } else {
            toReturn[0] = 0;
            toReturn[1] = ratio;
        }
        return;
    }
    
    //When X is not on the line.
    double s = innerProduct(Y1, Y1)-innerProduct(Y1, Y2)-innerProduct(X, Y1)+innerProduct(X, Y2);
    s /= scale;
    if (s>1) {
        toReturn[0] = sqrt(innerProduct(w, w));
        toReturn[1] = 1;
    } else if (s<0) {
        toReturn[0] = sqrt(innerProduct(u, u));
        toReturn[1] = 0;
    } else {
        for (int i=0;i<3;i++) {
            w[i] = -u[i]+s*v[i];
        }
        toReturn[0] = sqrt(innerProduct(w, w));
        toReturn[1] = s;
    }
    return;
}

double findMax(double *u, int start, int end){
    if (end-start<2) return fabs(u[end])>fabs(u[start])?fabs(u[end]):fabs(u[start]);
    double m1 = findMax(u,start,floor(end/2));
    double m2 = findMax(u,floor(end/2)+1,end);
    return m1>m2?m1:m2;
}

int ChromosomeArm::findClosestBead(double x,double y, double z, int excludedBead, int itself){
    const double *pointerD = position.Pointer();
    double minDist = __DBL_MAX__,dx,dy,dz,minDistTemp;
    int i3, toReturn;
    for (int i=0;i<numberOfBeads;i++) {
        i3 = 3*i;
        if (i == excludedBead || i == itself) continue;
        else {
            dx = x-pointerD[i3];
            dx = dx*dx;
            if (minDist<dx) continue;
            dy = y-pointerD[i3+1];
            dy = dy*dy;
            if (minDist<dy) continue;
            dz = z-pointerD[i3+2];
            dz = dz*dz;
            if (minDist<dz) continue;
            minDistTemp = dx+dy+dz;
            if (minDistTemp<minDist) {
                minDist = minDistTemp;
                toReturn = i;
            }
        }
    }
    return toReturn;
}

void ChromosomeArm::cohesinUnbindUpdate(const double unattachThreshold, DTRandom &random){
    const double* norm_array_pointer = normArray.Pointer();
    for (int i=0;i<cohesinInfo.numberOfCohesin;++i) {
        if (cohesinInfo.loopConfig[i]._time_started>=cohesinInfo._unattach_start_time && cohesinInfo.loopConfig[i].startBeadIndex>=0) {
            int start_bead = cohesinInfo.loopConfig[i].startBeadIndex;
            int end_bead = cohesinInfo.loopConfig[i].startBeadIndex+6;
            double max1 = max(norm_array_pointer[start_bead], norm_array_pointer[end_bead]);
            if (start_bead > 0) {start_bead--;}
            if (end_bead > 0) {end_bead--;}
            double max2 = max(norm_array_pointer[start_bead], norm_array_pointer[end_bead]);
            double dist = max(max1, max2);
            if (dist > unattachThreshold) {
                cohesinInfo.histoneDetach(i, cohesinInfo._unattach_time);
            }
        }
    }
}

double* ChromosomeArm::CentromereSpeed(const double speed){
    const double * data = position.Pointer();
    double dx = data[3*startBead] - data[3*endBead];
    double dy = data[3*startBead+1] - data[3*endBead+1];
    double dz = data[3*startBead+2] - data[3*endBead+2];
    double norm = sqrt(dx * dx + dy * dy + dz * dz);
    double * toReturn = new double[3];
    toReturn[0] = dx / norm * speed;
    toReturn[1] = dy / norm * speed;
    toReturn[2] = dz / norm * speed;
    return toReturn;
}

void ChromosomeArm::updateRandomCentromere(DTRandom &random) {
    double newLength = random.Normal(centromereMean, centromereStd);
    const double *data = position.Pointer();
    double dx = -data[3*startBead] + data[3*endBead];
    double dy = -data[3*startBead+1] + data[3*endBead+1];
    double dz = -data[3*startBead+2] + data[3*endBead+2];
    double norm = sqrt(dx * dx + dy * dy + dz * dz);
    position(0,endBead) = position(0,startBead) + dx * newLength / norm;
    position(1,endBead) = position(1,startBead) + dy * newLength / norm;
    position(2,endBead) = position(2,startBead) + dz * newLength / norm;
}

void ChromosomeArm::CentromereDetach() {
    const double *data = position.Pointer();
    double dx = -data[3*startBead] + data[3*endBead];
    double dy = -data[3*startBead+1] + data[3*endBead+1];
    double dz = -data[3*startBead+2] + data[3*endBead+2];
    double norm = dx * dx + dy * dy + dz * dz;
    if (norm > _centromere_dist_threshold) {
        _centromere_detached = true;
        endBead = -1;
    }
}

void ChromosomeArm::addCondensin(const int condensin_add_pos)
{
    condensinInfo.addCondensin(condensin_add_pos);
}

