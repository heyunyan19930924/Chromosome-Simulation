// #include "DTSource.h"
#include "DTSaveError.h"
#include "DTSeriesGroup.h"
#include "DTArguments.h"
#include "DTDataFile.h"
#include "DTDictionary.h"
#include "DTDoubleArray.h"
#include "DTMatlabDataFile.h"
#include "DTPath3D.h"
#include "DTProgress.h"
#include "DTSeriesPath3D.h"
#include "DTRandom.h"
#include "unitConversion.h"
#include "ChromosomeArm.hpp"
#include "cohesin.hpp"
#include "condensin.hpp"


//////////////////////////////////////////////////////////////////////////////
//    DT_RetGroup
//////////////////////////////////////////////////////////////////////////////

struct DT_RetGroup {
    DTPath3D Var;
    DTDoubleArray centromereForce;
    DTIntArray condensin;
    
    void pinfo(void) const;
    void pinfoIndent(string) const;
    
    static void WriteStructure(DTDataStorage &,string);
};

void DT_RetGroup::pinfo(void) const
{
    pinfoIndent("");
}

void DT_RetGroup::pinfoIndent(string pad) const
{
    cerr << pad << "Var = "; Var.pinfo();
    cerr << pad << "centromereForce = "; centromereForce.pinfo();
    cerr << pad << "condensin = "; condensin.pinfo();
}

void DT_RetGroup::WriteStructure(DTDataStorage &output,string name)
{
    output.Save("Var",name+"_1N");
    output.Save("Path3D",name+"_1T");
    
    output.Save("centromereForce",name+"_2N");
    output.Save("Array",name+"_2T");
    
    output.Save("condensin",name+"_3N");
    output.Save("Array",name+"_3T");
    
    output.Save(3,name+"_N");
    output.Save("Group",name);
}

extern void Write(DTDataStorage &,string name,const DT_RetGroup &);

void Write(DTDataStorage &output,string name,const DT_RetGroup &var)
{
    Write(output,name+"_Var",var.Var);
    Write(output,name+"_centromereForce",var.centromereForce);
    Write(output,name+"_condensin",var.condensin);
    Write(output,name,DTDoubleArray()); // So that DataTank can see the variable.
}

//////////////////////////////////////////////////////////////////////////////
//    Main routine
//////////////////////////////////////////////////////////////////////////////

void Computation(const DTDictionary &Coefficients,const DTDictionary &flags,
                 const DTDictionary &evolution,const DTDoubleArray &loop_nodes,
                 double seed,const DTDictionary &histone,
                 const DTDictionary &condensin,
                 const DTDictionary &addCondensin,
                 const DTDictionary &differentSpringProperty,
                 DTSeriesGroup<DT_RetGroup> &computed);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    DTMatlabDataFile outputFile("Output.mat",DTFile::NewReadWrite);
    
    // Input variables.
    DTDictionary Coefficients;
    Read(inputFile,"Coefficients",Coefficients);
    DTDictionary flags;
    Read(inputFile,"flags",flags);
    DTDictionary evolution;
    Read(inputFile,"evolution",evolution);
    DTDoubleArray loop_nodes = inputFile.ReadDoubleArray("loop_nodes");
    double seed = inputFile.ReadNumber("seed");
    DTDictionary histone;
    Read(inputFile,"histone",histone);
    DTDictionary condensin;
    Read(inputFile,"condensin",condensin);
    DTDictionary addCondensin;
    Read(inputFile,"addCondensin",addCondensin);
    DTDictionary differentSpringProperty;
    Read(inputFile,"differentSpringProperty",differentSpringProperty);
    
    // Output series.
    DTSeriesGroup<DT_RetGroup> computed(outputFile,"Var");
    if (DTArgumentIncludesFlag("saveInput")) { // Add -saveInput to the argument list to save the input in the output file.
        WriteOne(outputFile,"Coefficients",Coefficients);
        WriteOne(outputFile,"flags",flags);
        WriteOne(outputFile,"evolution",evolution);
        WriteOne(outputFile,"loop_nodes",loop_nodes);
        WriteOne(outputFile,"seed",seed);
        WriteOne(outputFile,"histone",histone);
        WriteOne(outputFile,"condensin",condensin);
        WriteOne(outputFile,"addCondensin",addCondensin);
        WriteOne(outputFile,"differentSpringProperty",differentSpringProperty);
    }
    
    
    // The computation.
    clock_t t_before = clock();
    Computation(Coefficients,flags,evolution,loop_nodes,seed,histone,condensin,addCondensin,differentSpringProperty,computed);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    return 0;
}


//////////////////////////////////////////////////////////////////////////////
//    Computational routine
//////////////////////////////////////////////////////////////////////////////

DTPath3D ConvertPointsToPath(const DTMutableDoubleArray &points);

DTPath3D ConvertPointsToPath(const DTMutableDoubleArray &points)
{
    int n = points.n();
    DTMutableDoubleArray loop(3,n+1);
    // loop = NAN;
    loop(0,0) = 0;
    loop(1,0) = 0;
    loop(2,0) = n;
    
    MemoryCopyColumns(loop,1,points,DTRange(0,n));
    
    return DTPath3D(loop);
}

void Computation(const DTDictionary &Coefficients,const DTDictionary &flags,
                 const DTDictionary &evolution,const DTDoubleArray &loop_nodes,
                 double seed,const DTDictionary &histone,
                 const DTDictionary &condensin,
                 const DTDictionary &addCondensin,
                 const DTDictionary &differentSpringProperty,
                 DTSeriesGroup<DT_RetGroup> &computed)
{
    //Read in parameters and flags.
    
    DTProgress progress;
    DT_RetGroup to_update_group;
    
    bool histoneFlag = flags("histone");
    bool condensinFlag = flags("condensin");
    bool staticLooping = flags("static_looping");
    bool spring = flags("spring");
    bool thermoMotion = flags("thermo_motion");
    bool collision = flags("collision");
    bool hinge = flags("hinge");
    bool cylinderCollision = flags("cylinderCollision");
    bool fixOneSite = condensin("fixOneSite");
    bool histoneUnbind = histone("unattach");
    bool stretchingCentromere = flags("stretchingCentromere");
    bool oscillatingCentromere = flags("oscillatingCentromere");
    bool centromere_detach = flags("centromereDetach");

    double until = evolution("until");
    double save_stride = evolution("save_stride");
    double dt = evolution("timeStep");
    int numberOfArms = evolution("numberOfArms");
    int numberOfNodes = evolution("numberOfNodes");
    double displacementCap = evolution("displacementCap");
    double unattachTime = histone("unattachTime");
    double unattachThreshold = histone("unattachThreshold");
    double stretchingSpeedPerSecond = evolution("stretchingSpeedPerSecond");
    int startBead = evolution("startBead");
    int endBead = evolution("endBead");
    double stretchingStartTime = evolution("stretchingStartTime");
    double condensinResetTime = condensin("unbindTime");
    double extrusionRatePower = condensin("extrusionRatePower");
    double centromereUpdateTime = Coefficients("centromereUpdateTime");
    
    double t = 0;
    double tCurrent = 0;
    double dtCurrent = dt;
    double tol = dt * 1e-4;
    double save_stride_judge = save_stride - tol;
    double currentMaxForce;
    double forceCap = displacementCap/dt;
    double centromereT = centromereUpdateTime;
    DTRandom random(seed);
    default_random_engine generator(seed);
    
    // Module that adds condensin
    bool add_condensin_during_simulation = addCondensin("activate");
    const double condensin_add_time = addCondensin("add_time");
    const int condensin_add_pos = addCondensin("add_pos");
    const double condensin_add_start_time = addCondensin("add_start_time");
    double condensin_time_tracker = condensin_add_time;
    
    // Initialize data structures.
    ChromosomeArm armList = ChromosomeArm(t, dt, 0, Coefficients, evolution, flags, differentSpringProperty, seed, numberOfNodes);
    
    if (histoneFlag) {
        int numberOfCohesin = histone("numberOfHistones");
        double halfLifeOn = histone("halfLifeOn");
        double halfLifeOff = histone("halfLifeOff");
        double halfLifeVariance = histone("halfLifeVariance");
        double unattach_time = histone("unattachTime");
        double unattach_start_time = histone("unattachStartTime");
        Cohesin CohesinTemp = Cohesin(numberOfCohesin, halfLifeOn, halfLifeOff, halfLifeVariance, numberOfNodes, random, generator, unattach_time, unattach_start_time);
        armList.cohesinInfo = CohesinTemp;
    }
    
    if (condensinFlag) {
        int numberOfCondensin = condensin("numberOfCondensins");
        double judgeTimeSeconds = condensin("judgeTimeSeconds");
        double incrementNanometers  = condensin("incrementNanometers");
        double criticalLengthNanometers = condensin("criticalLengthNanometers");
        double unbindTime = condensin("unbindTime");
        double unbindTimeVar = condensin("unbindTimeVar");
        double rebindTime = condensin("rebindTime");
        bool unbindCondensin = condensin("unbind");
        bool dynamicExtrusionRate = condensin("dynamicExtrusionRate");
        Condensin condensinTemp = Condensin(numberOfCondensin, judgeTimeSeconds, criticalLengthNanometers, incrementNanometers, numberOfNodes, seed, unbindTime, rebindTime, unbindTimeVar, unbindCondensin, dynamicExtrusionRate);
        armList.condensinInfo = condensinTemp;
    }
    
    //If centromere is moving, compute the moving velocity at the first place to avoid computing it every time.
    double* centromereSpeed = armList.CentromereSpeed(stretchingSpeedPerSecond);

    //Add first time step to output.
    DTMutableDoubleArray to_update = armList.position.Copy();
    to_update *= 1e-9;
    DTMutableDoubleArray to_update_centromere_force(3,2);
    for (int i = 0; i < 3; ++i) {
        to_update_centromere_force(i,0) = armList.forceArray(i,startBead);
        to_update_centromere_force(i,1) = armList.forceArray(i,endBead);
    }
    to_update_group.Var = ConvertPointsToPath(to_update);
    to_update_group.centromereForce = to_update_centromere_force.Copy();
    to_update_group.condensin = armList.condensinInfo.condensin_array.Copy();
    computed.Add(to_update_group,t);

    //Main loop
    while (t<until) {
        //compute dynamic time step to avoid instablity lead by all forces.
        armList.initializeForce();
        armList.computeDistance();
        
        if (spring) armList.springForceUpdate();
        if (hinge) armList.hingeForceUpdate();
        if (staticLooping) armList.loopForceUpdate(loop_nodes);
        if (collision) armList.excludedVolumeUpdate();
        if (cylinderCollision) armList.cylinderForceUpdateSelf();
        if (histoneFlag) {
            armList.cohesinForceUpdate();
        }
        if (condensinFlag) {
            //armList.condensinTensionDetect();
            armList.condensinForceUpdate();
        }
        
        //Determine dynamic timestep for this run
        currentMaxForce = armList.findMaxForce();
        dtCurrent = dt;
        if (currentMaxForce>forceCap) {
            dtCurrent = displacementCap/currentMaxForce;
        }
        
        //Determine random motion parameters based on time step.
        if (thermoMotion) armList.randomForceUpdate(random,dtCurrent);
        //If centromeres are moving
        if (stretchingCentromere && t > stretchingStartTime &&
            !armList._centromere_detached) {
            for (int k=0;k<3;++k) {
                armList.position(k,startBead) += centromereSpeed[k] * dtCurrent;
                armList.position(k,endBead) -= centromereSpeed[k] * dtCurrent;
            }
            if (centromere_detach) armList.CentromereDetach();
        }
        
        if (oscillatingCentromere && t > stretchingStartTime &&
            !armList._centromere_detached) {
            centromereT -= dtCurrent;
            if (centromereT <= 0) {
                centromereT += centromereUpdateTime;
                armList.updateRandomCentromere(random);
            }
        }

        armList.positionUpdateTemp(dtCurrent);
        
        t += dtCurrent;
        tCurrent += dtCurrent; // to store time period for output.
        if (histoneFlag) {
            if (histoneUnbind) armList.cohesinUnbindUpdate(unattachThreshold,random);
            armList.cohesinInfo.updateTime(dtCurrent, random);
        }
        if (condensinFlag) {
            // Module that adds condensin
            if (add_condensin_during_simulation && t > condensin_add_start_time) {
                condensin_time_tracker -= dtCurrent;
                if (condensin_time_tracker <= 0) {
                    condensin_time_tracker = condensin_add_time;
                    armList.addCondensin(condensin_add_pos);
                }
            }
            
            if (!fixOneSite) armList.updateCondensinTime(dtCurrent, extrusionRatePower, random);
            else armList.updateCondensinTimeFixedOneSite(dtCurrent, extrusionRatePower, random);
        }
        
        if (tCurrent > save_stride_judge) {
            progress.UpdatePercentage(t/until);
            to_update = armList.position.Copy();
            to_update *= 1e-9;
            for (int i = 0; i < 3; ++i) {
                to_update_centromere_force(i,0) = armList.forceArray(i,startBead);
                to_update_centromere_force(i,1) = armList.forceArray(i,endBead);
            }
            to_update_centromere_force *= 1e-9;
            to_update_group.Var = ConvertPointsToPath(to_update);
            to_update_group.centromereForce = to_update_centromere_force.Copy();
            to_update_group.condensin = armList.condensinInfo.condensin_array.Copy();
            computed.Add(to_update_group,t);
            tCurrent -= save_stride;
        }
    }
}

