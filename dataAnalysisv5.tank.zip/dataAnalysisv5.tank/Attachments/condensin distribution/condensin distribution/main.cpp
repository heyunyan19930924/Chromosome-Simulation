// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTPath3D.h"
#include "DTPointCollection3D.h"
#include "DTSeriesArray.h"
#include "DTSeriesPath3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"
#include "DTSeriesArray.h"
#include <math.h>

DTPointCollection3D Computation(int total_instance,DTSeriesPath3D &chromosome_arm,
                                DTSeriesArray &condensin_location);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    double total_instance = inputFile.ReadNumber("total_instance");
    DTSeriesPath3D chromosome_arm;
    Read(inputFile,"chromosome_arm",chromosome_arm);
    DTSeriesArray condensin_location;
    Read(inputFile,"condensin_location",condensin_location);
    
    // The computation.
    DTPointCollection3D computed;
    clock_t t_before = clock();
    computed = Computation(total_instance,chromosome_arm,condensin_location);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    Write(outputFile,"Var",computed);
    outputFile.Save("PointCollection3D","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

DTPointCollection3D Computation(int total_instance,DTSeriesPath3D &chromosome_arm,
                                DTSeriesArray &condensin_location)
{
    int total_timesteps = chromosome_arm.HowManySaved();
    int timestep = total_timesteps / total_instance;
    int cur_time = timestep;
    DTMutableDoubleArray to_return_data(3, 100);
    DTDoubleArray time_array = chromosome_arm.TimeValues();
    //const double* time_array = chromosome_arm.TimeValues().Pointer();
    int array_size = 100;
    int cur_array_pos = 0;
    while (cur_time < total_timesteps) {
        DTDoubleArray cur_condensin = condensin_location.Get(time_array(cur_time));
        const double* cur_condensin_pointer = cur_condensin.Pointer();
        const double* cur_path_pointer = chromosome_arm(cur_time).Data().Pointer();
        int number_of_condensin = cur_condensin.m()*cur_condensin.n();
        for (int i = 0; i < number_of_condensin; ++i) {
            if (cur_array_pos >= array_size) {
                // Expand to_return_data
                to_return_data = IncreaseSize(to_return_data, 3*100);
                array_size += 100;
            }
            int cur_condensin_label = 3 * (cur_condensin_pointer[i] + 1);
            to_return_data(0,cur_array_pos) = cur_path_pointer[cur_condensin_label];
            to_return_data(1,cur_array_pos) = cur_path_pointer[cur_condensin_label + 1];
            to_return_data(2,cur_array_pos) = cur_path_pointer[cur_condensin_label + 2];
            cur_array_pos++;
        }
        cur_time += timestep;
    }
    // Truncate to_return_data;
    to_return_data = TruncateSize(to_return_data, 3 * cur_array_pos);
    DTPointCollection3D toReturn(to_return_data);
    return toReturn;
}
