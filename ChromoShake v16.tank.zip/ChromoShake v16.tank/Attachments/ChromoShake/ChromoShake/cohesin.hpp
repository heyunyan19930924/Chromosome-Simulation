//
//  cohesin.hpp
//  ChromoShake
//
//  Created by HeYunyan on 9/26/17.
//

#ifndef cohesin_hpp
#define cohesin_hpp
#include <stdio.h>
#include "DTArguments.h"
#include "DTDataFile.h"
#include "DTDictionary.h"
#include "DTPath3D.h"
#include "DTProgress.h"
#include "DTSeriesPath3D.h"
#include "DTRandom.h"
#include "DTUtilities.h"
#include "DTPointCollection3D.h"
#include <algorithm>
#include <random>
#include "DTRandom.h"
#include <unordered_set>

struct cohesinUnit{
    //constructor
    cohesinUnit() {startBeadIndex = 0; remainingTime = 0; _time_started = 0;};
    cohesinUnit(int i, double j) {startBeadIndex = i; remainingTime = j; _time_started = 0;};
    
    int startBeadIndex;
    double remainingTime;
    double _time_started;
};

class Cohesin{
public:
    Cohesin() {};
    Cohesin(int NumberOfCohesin, double halfLifeOn, double halfLifeOff, double Variance, int numberOfBeads, DTRandom &timeGenerator, default_random_engine &generator, double unattach_time, double unattach_start_time);
    int numberOfCohesin, numberOfTotalBeads;
    double halflifeOn, halflifeOff, variance;
    double _unattach_time, _unattach_start_time;
    
    // loopConfig.startBeadIndex stores starting node of each loop, loopConfig.remainingTime stores loop time.
    vector<cohesinUnit> loopConfig;
    // availableBeads stores beads that are candidate loop start.
    unordered_set<int> availableBeads;
    // beadsNotInLoop stores beads that are not in loops.
    unordered_set<int> beadsNotInLoop;
    
    void updateTime(const double dt, DTRandom &timeGenerator);
    void histoneDetach(const int index, const double detach_time);
    void histoneInsert(const int index, const double binding_time);
};

#endif /* cohesin_hpp */
