// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPath3D.h"
#include "DTSeriesArray.h"
#include "DTSeriesPath3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTDoubleArray Computation(const DTSeriesPath3D &chromosome,const DTSeriesArray &condensin_location);

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTSeriesPath3D chromosome;
    Read(inputFile,"chromosome",chromosome);
    DTSeriesArray condensin_location;
    Read(inputFile,"condensin_location",condensin_location);
    
    // The computation.
    DTDoubleArray computed;
    clock_t t_before = clock();
    computed = Computation(chromosome,condensin_location);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    outputFile.Save(computed,"Var");
    outputFile.Save("NumberList","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

DTDoubleArray Computation(const DTSeriesPath3D &chromosome,const DTSeriesArray &condensin_location)
{
    const int total_timestep = chromosome.HowManySaved();
    const DTDoubleArray time_values = chromosome.TimeValues();
    int number_of_condensins = condensin_location.Get(time_values(0)).n();
    DTMutableDoubleArray toReturn(number_of_condensins);
    int cur_index = 0;
    DTDoubleArray cur_condensin_location = condensin_location.Get(time_values(cur_index));
    DTMutableDoubleArray prev_moving_site(number_of_condensins);
    DTMutableDoubleArray moving_count(number_of_condensins);
    for (int i = 0; i < number_of_condensins; ++i) {
        prev_moving_site(i) = cur_condensin_location(1,i);
    }
    cur_index++;
    while (cur_index < total_timestep) {
        DTDoubleArray cur_condensin_location = condensin_location.Get(time_values(cur_index));
        for (int j = 0; j < number_of_condensins; ++j) {
            if (cur_condensin_location(1,j) != prev_moving_site(j)) {
                moving_count(j)++;
                prev_moving_site(j) = cur_condensin_location(1,j);
            }
        }
        
        cur_index++;
    }
    for (int i = 0; i < number_of_condensins; ++i) {
        toReturn(i) = time_values(total_timestep - 1) / moving_count(i);
    }
    return toReturn;
}
