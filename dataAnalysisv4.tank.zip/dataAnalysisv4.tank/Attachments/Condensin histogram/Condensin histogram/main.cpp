// Include DTSource.h if you want to include all the headers.

#include "DTArguments.h"
#include "DTSaveError.h"

#include "DTDataFile.h"
#include "DTDoubleArray.h"
#include "DTPoint3D.h"
#include "DTPointCollection3D.h"

// Common utilities
#include "DTDoubleArrayOperators.h"
#include "DTProgress.h"
#include "DTTimer.h"
#include "DTUtilities.h"
#include "DTDictionary.h"

#include <math.h>

DTDoubleArray Computation(const DTPointCollection3D &condensin_distribution,const DTPoint3D &end_bead_1,
                          const DTPoint3D &end_bead_2);

double compute_norm(const double* v) {
    return sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}

double inner_product(const double* v1, const double *v2) {
    return v1[0]*v2[0] + v1[1]*v2[1] + v1[2]*v2[2];
}

int main(int argc,const char *argv[])
{
    DTSetArguments(argc,argv);
    
    DTDataFile inputFile("Input.dtbin",DTFile::ReadOnly);
    // Read in the input variables.
    DTPointCollection3D condensin_distribution;
    Read(inputFile,"condensin_distribution",condensin_distribution);
    DTPoint3D end_bead_1;
    Read(inputFile,"end_bead_1",end_bead_1);
    DTPoint3D end_bead_2;
    Read(inputFile,"end_bead_2",end_bead_2);
    
    // The computation.
    DTDoubleArray computed;
    clock_t t_before = clock();
    computed = Computation(condensin_distribution,end_bead_1,end_bead_2);
    clock_t t_after = clock();
    double exec_time = double(t_after-t_before)/double(CLOCKS_PER_SEC);
    
    // Write the output.
    DTDataFile outputFile("Output.dtbin",DTFile::NewReadWrite);
    
    // Output from computation
    outputFile.Save(computed,"Var");
    outputFile.Save("NumberList","Seq_Var");
    
    // The execution time.
    outputFile.Save(exec_time,"ExecutionTime");
    outputFile.Save("Real Number","Seq_ExecutionTime");
    
    // The errors.
    DTSaveError(outputFile,"ExecutionErrors");
    outputFile.Save("StringList","Seq_ExecutionErrors");
    
    outputFile.SaveIndex();
    
    return 0;
}

DTDoubleArray Computation(const DTPointCollection3D &condensin_distribution,const DTPoint3D &end_bead_1,
                          const DTPoint3D &end_bead_2)
{
    int total_number = condensin_distribution.DoubleData().n();
    DTMutableDoubleArray toReturn(total_number);
    const double v[3] = {end_bead_2.x - end_bead_1.x,
                         end_bead_2.y - end_bead_1.y,
        end_bead_2.x - end_bead_1.z};
    const double v_norm = compute_norm(v);
    const double* condensin_distribution_pointer = condensin_distribution.DoubleData().Pointer();
    for (int i = 0; i < total_number; ++i) {
        double s[3] = {condensin_distribution_pointer[3*i] - end_bead_1.x,
            condensin_distribution_pointer[3*i+1] - end_bead_1.y,
            condensin_distribution_pointer[3*i+2] - end_bead_1.z,
        };
        double distance = inner_product(s, v) / v_norm;
        toReturn(i) = distance;
    }
    return toReturn;
}
